from django.shortcuts import render, HttpResponse, redirect

# Create your likes app views.


def likes(request):
    response = "This is the index page"
    return HttpResponse(response)
